CREATE PROCEDURE do_aws_insert(IN p_zone_id VARCHAR(26), IN p_name VARCHAR(60), IN p_ttl INT,
                               IN p_type    ENUM ('SOA', 'A', 'TXT', 'NS', 'CNAME', 'MX', 'PTR', 'SRV', 'SPF', 'AAAA'),
                               IN p_value   VARCHAR(256))
  BEGIN
    SET @zone_id = (SELECT record_id FROM AWS_Route53_zones WHERE zone_id = p_zone_id);

    IF p_ttl = 0 THEN
      INSERT IGNORE INTO AWS_Route53 (name, type, hosted_zone_id) VALUES (p_name, p_type, @zone_id);
    ELSE 
      INSERT IGNORE INTO AWS_Route53 (name, type, ttl, hosted_zone_id) VALUES (p_name, p_type, p_ttl, @zone_id);
    END IF;
  
    SET @last_id = (SELECT LAST_INSERT_ID());

    REPLACE INTO AWS_Route53_values (AWS_record_id, value, last_update) VALUES (@last_id, p_value, NOW());

  END;
