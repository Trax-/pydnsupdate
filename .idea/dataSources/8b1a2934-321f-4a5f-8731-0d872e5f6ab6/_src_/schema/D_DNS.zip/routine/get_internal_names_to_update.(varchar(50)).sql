CREATE PROCEDURE get_internal_names_to_update(IN p_name VARCHAR(50))
  BEGIN
	SELECT ext_name as rname
              FROM router_names
              JOIN routers
              ON routers.router_id = router_names.router_id
              WHERE name = p_name AND name != 'www';
END;
