CREATE PROCEDURE do_internal_update(IN p_router_id INT, IN p_ip_address VARCHAR(50))
  BEGIN
    SET @date_now = NOW();

    UPDATE ip_address
    SET active = 'N'
    WHERE router_id = p_router_id;

    INSERT INTO ip_address (router_id, ip_address, updated, active) VALUES (p_router_id, p_ip_address, @date_now, 'Y');

  END;
