CREATE VIEW dnspark_names AS
  SELECT
    `D_DNS`.`router_names`.`ext_name` AS `rname`,
    `D_DNS`.`routers`.`name`          AS `name`,
    `D_DNS`.`DNS_Park`.`rdata`        AS `rdata`,
    `D_DNS`.`DNS_Park`.`rtype`        AS `rtype`,
    `D_DNS`.`DNS_Park`.`ttl`          AS `ttl`,
    `D_DNS`.`DNS_Park`.`dynamic`      AS `dynamic`,
    `D_DNS`.`DNS_Park`.`record_id`    AS `record_id`
  FROM (`D_DNS`.`router_names`
    JOIN (`D_DNS`.`routers`
      JOIN `D_DNS`.`DNS_Park`) ON (((`D_DNS`.`routers`.`router_id` = `D_DNS`.`router_names`.`router_id`) AND
                                    (substr(`D_DNS`.`DNS_Park`.`rname`, 1, 3) =
                                     substr(`D_DNS`.`router_names`.`ext_name`, 1, 3)))))
  WHERE (`D_DNS`.`DNS_Park`.`rtype` = 'A');
