CREATE VIEW latest AS
  SELECT
    `D_DNS`.`routers`.`name`          AS `name`,
    `D_DNS`.`routers`.`command`       AS `command`,
    `D_DNS`.`routers`.`command2`      AS `command2`,
    `D_DNS`.`routers`.`router_id`     AS `router_id`,
    `D_DNS`.`routers`.`OID`           AS `oid`,
    `D_DNS`.`ip_address`.`ip_address` AS `address`,
    `D_DNS`.`ip_address`.`updated`    AS `updated`
  FROM (`D_DNS`.`routers`
    JOIN `D_DNS`.`ip_address` ON ((`D_DNS`.`routers`.`router_id` = `D_DNS`.`ip_address`.`router_id`)))
  WHERE (`D_DNS`.`ip_address`.`active` = 'Y');
